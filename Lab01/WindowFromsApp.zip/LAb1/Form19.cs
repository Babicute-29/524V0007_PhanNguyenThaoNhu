﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void Form19_Load(object sender, EventArgs e)
        {
            Button btn1 = new Button() { Text = "Button 1" };
            Button btn2 = new Button() { Text = "Button 2" };
            Button btn3 = new Button() { Text = "Button 3" };

            flowLayoutPanel1.Controls.Add(btn1);
            flowLayoutPanel1.Controls.Add(btn2);
            flowLayoutPanel1.Controls.Add(btn3);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
