﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form11());
            Application.Run(new Form12());
            Application.Run(new Form13());
            Application.Run(new Form14());
            Application.Run(new Form15());
            Application.Run(new Form16());
            Application.Run(new Form17());
            Application.Run(new Form18());
            Application.Run(new Form19());
            Application.Run(new Form20());
        }
    }
}
