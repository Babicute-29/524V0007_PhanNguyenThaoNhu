﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Homeworklab2
{
    public partial class StudentEnrollmentsForm : Form
    {
        string connStr =
        ConfigurationManager.ConnectionStrings["SchoolDBConnectionString"].ConnectionString;

        public StudentEnrollmentsForm()
        {
            InitializeComponent();
        }

        // Khi form load
        private void StudentEnrollmentsForm_Load(object sender, EventArgs e)
        {
            LoadCourses();
        }

        // Load danh sách course vào ComboBox
        void LoadCourses()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand("GetCourses", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                comboBoxCourses.DataSource = dt;
                comboBoxCourses.DisplayMember = "CourseName";
                comboBoxCourses.ValueMember = "CourseID";
            }
        }

        // Load sinh viên theo Course
        void LoadData()
        {
            if (comboBoxCourses.SelectedValue == null) return;

            int courseID = Convert.ToInt32(comboBoxCourses.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT * FROM tblStudentCourses WHERE CourseID=@cid", conn);
                da.SelectCommand.Parameters.AddWithValue("@cid", courseID);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void comboBoxCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadData();
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            int studentID =
                Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["StudentID"].Value);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM tblStudentCourses WHERE StudentID=@sid", conn);
                cmd.Parameters.AddWithValue("@sid", studentID);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            int studentID =
                Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["StudentID"].Value);
            int courseID = Convert.ToInt32(comboBoxCourses.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    "UPDATE tblStudentCourses SET CourseID=@cid WHERE StudentID=@sid", conn);
                cmd.Parameters.AddWithValue("@sid", studentID);
                cmd.Parameters.AddWithValue("@cid", courseID);
                cmd.ExecuteNonQuery();
                LoadData();
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (comboBoxCourses.SelectedValue == null) return;

            int courseID = Convert.ToInt32(comboBoxCourses.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO tblStudentCourses(StudentID,CourseID) VALUES (1,@cid)", conn);
                // StudentID = 1 (hard-code theo Lab)
                cmd.Parameters.AddWithValue("@cid", courseID);
                cmd.ExecuteNonQuery();
                LoadData();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}
