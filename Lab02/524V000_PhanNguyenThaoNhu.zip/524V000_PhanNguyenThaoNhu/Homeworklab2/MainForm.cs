﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homeworklab2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void StudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new StudentsForm().Show();
        }

        private void CoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CoursesForm().Show();
        }

        private void InstructorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new InstructorsForm().Show();
        }

        private void departmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new DepartmentsForm().Show();
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
