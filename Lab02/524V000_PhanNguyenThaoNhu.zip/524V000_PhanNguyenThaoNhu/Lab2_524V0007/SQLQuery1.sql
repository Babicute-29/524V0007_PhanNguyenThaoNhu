CREATE DATABASE Lab2;
USE Lab2;

CREATE TABLE tblUsers (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50),
    Password NVARCHAR(50)
);

INSERT INTO tblUsers VALUES ('user1','password1');
INSERT INTO tblUsers VALUES ('user2','password2');

SELECT * FROM tblUsers;


CREATE TABLE tblStudents (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    StudentName NVARCHAR(100),
    DateOfBirth DATE,
    City NVARCHAR(50),
    Age INT,
    YearOfEnroll INT,
    Major NVARCHAR(50),
    GPA DECIMAL(3,2)
);

INSERT INTO tblStudents VALUES
('Trung Pham','2000-01-15','HCMC',24,2018,'Computer Science',3.5),
('Jane Smith','1999-05-22','LA',25,2017,'Math',3.8);
