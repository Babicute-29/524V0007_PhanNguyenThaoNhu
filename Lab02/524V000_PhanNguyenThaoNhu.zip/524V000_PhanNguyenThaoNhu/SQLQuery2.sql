CREATE DATABASE homlab;
USE homlab;
GO

-- =========================
-- Departments
-- =========================
CREATE TABLE tblDepartments (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    DepartmentName NVARCHAR(100) NOT NULL
);
GO

INSERT INTO tblDepartments (DepartmentName) VALUES
('Computer Science'),
('Mathematics'),
('Physics'),
('Chemistry');
GO

-- =========================
-- Instructors
-- =========================
CREATE TABLE tblInstructors (
    InstructorID INT IDENTITY(1,1) PRIMARY KEY,
    InstructorName NVARCHAR(100) NOT NULL,
    DepartmentID INT NOT NULL
);
GO

INSERT INTO tblInstructors (InstructorName, DepartmentID) VALUES
('Dr. John Smith', 1),
('Dr. Jane Doe', 2),
('Dr. Alice Brown', 3),
('Dr. Bob White', 4);
GO

-- =========================
-- Courses
-- =========================
CREATE TABLE tblCourses (
    CourseID INT IDENTITY(1,1) PRIMARY KEY,
    CourseName NVARCHAR(100) NOT NULL,
    Credits INT NOT NULL,
    DepartmentID INT NOT NULL,
    InstructorID INT NOT NULL
);
GO

INSERT INTO tblCourses (CourseName, Credits, DepartmentID, InstructorID) VALUES
('Introduction to Computer Science', 3, 1, 1),
('Calculus I', 4, 2, 2),
('Physics I', 4, 3, 3),
('Organic Chemistry', 4, 4, 4);
GO

-- =========================
-- Students
-- =========================
CREATE TABLE tblStudents (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    StudentName NVARCHAR(100),
    Email NVARCHAR(100)
);
GO

INSERT INTO tblStudents (StudentName, Email) VALUES
('Nguyen Van A', 'a@gmail.com'),
('Tran Thi B', 'b@gmail.com'),
('Le Van C', 'c@gmail.com'),
('Pham Thi D', 'd@gmail.com');
GO

-- =========================
-- StudentCourses (Enrollment)
-- =========================
CREATE TABLE tblStudentCourses (
    StudentID INT,
    CourseID INT,
    PRIMARY KEY (StudentID, CourseID),
    FOREIGN KEY (StudentID) REFERENCES tblStudents(StudentID),
    FOREIGN KEY (CourseID) REFERENCES tblCourses(CourseID)
);
GO

INSERT INTO tblStudentCourses (StudentID, CourseID) VALUES
(1,1),(1,2),(2,3),(3,4),(4,1),(4,3);
GO

-- =========================
-- Users
-- =========================
CREATE TABLE tblUsers (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50),
    Password NVARCHAR(50)
);
GO

INSERT INTO tblUsers (Username, Password)
VALUES ('admin','123');
GO

-- =========================
-- Stored Procedure
-- =========================
CREATE PROCEDURE GetCourses
AS
BEGIN
    SELECT CourseID, CourseName
    FROM tblCourses;
END;
GO
